#include <iostream>
using namespace std;

template <class T>
class String
{
    T *str;
    int l;
    public:
    String(T *v,int size)
    {
        int x;
        l=size;
        str = new T[l];
        for(x=0;x<size;x++)
        {
            str[x]=(T)v[x];    
        }
    }
    void print()
    {
        cout<<"\nString is "<<str<<" and its length is "<<l<<"\n";
    }
    friend void compare(String &a,String &b)
    {
        cout<<"\n";
        int i=0;
        int j=0;
        while(i<a.l || j<b.l)
        {
            if(a.str[i]<b.str[j])
            {
                cout<<"String "<<b.str<<" is greater than String "<<a.str<<"\n";
                return;
            }
            else if(a.str[i]>b.str[j])
            {
                cout<<"String "<<a.str<<" is greater than String "<<b.str<<"\n";
                return;
            }
            else
            {
                i++;
                j++;
            }
        }
        cout<<"Strings are equal"<<"\n";
    }
    friend void match(String &a,String &b)
    {
        cout<<"\n";
        int m=0;
        int n=0;
        int c=0;
        while(m<a.l && n<b.l)
        {
            if(c==b.l)
            {
                cout<<"Substring found at index "<<m-c<<"\n";
                return;
            }
            if(a.str[m]==b.str[n])
            {
                m++;
                n++;
                c++;
            }
            else
            {
                n=0;
                m++;
            }
        }
        if(c==b.l)
        {
            cout<<"Substring "<<b.str<<" found at index "<<m-c<<" of String "<<a.str<<"\n";
            return;
        }
        cout<<"Substring "<<b.str<<" not found in String "<<a.str<<"\n";
    }
};

int main()
{
    char* num="Prashant";
    String <char> v(num,8);
    v.print();
    
    char *name="ash";
    String <char> u(name,3);
    u.print();
    
    match(v,u);
    return 0;
}


