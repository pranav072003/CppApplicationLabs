#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "myLib.c"

int main(void)
{
    /////////////////////////////////////////////////////////
    // code to be measured
    double x=100.0, y=200.0;
    for (long long i =0; i< 100000;i++) {
        printf("%ld\n",i);
        Swap(&x,&y,sizeof(double));
    }
    return 0;
}
