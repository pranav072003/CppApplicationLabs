#include <iostream>
#include <fstream>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <iomanip>
#include <cstdlib>
using namespace std;

#ifndef MYTIMER_H_INCLUDED
#define MYTIMER_H_INCLUDED
#include <windows.h>
class myTimer{
 LARGE_INTEGER Frequency;
 LARGE_INTEGER startTime;
 LARGE_INTEGER endTime;
 double interval;
public:
 myTimer() { QueryPerformanceFrequency(&Frequency); }
 void StartTimer(){ QueryPerformanceCounter(&startTime); }
 void EndTimer(){ QueryPerformanceCounter(&endTime); }
 double GetInterval() {
 return (double) (endTime.QuadPart - startTime.QuadPart) / Frequency.QuadPart;
 }
};
#endif

class Selection
{
    public:
        int comp=0;
        
        void swap(int *a, int *b)
        {
            int temp = *a;
            *a = *b;
            *b = temp;
        }


        void selectionSort(int array[], int size) 
        {
            for (int step = 0; step < size - 1; step++) 
            {
                int min_idx = step;
                for (int i = step + 1; i < size; i++) 
                {
                    comp++;
                    if (array[i] < array[min_idx])
                    min_idx = i;
                }
                swap(&array[min_idx], &array[step]);
            }
        }
};

class Insertion
{
    public:
        int comp=0;
    
        void insertionSort(int array[], int size)
        {
            for (int step = 1; step < size; step++) 
            {
                int key = array[step];
                int j = step - 1;
                comp+=j;
                while (key < array[j] && j >= 0) 
                {
                    array[j + 1] = array[j];
                    --j;
                }
                array[j + 1] = key;
            }
        }
};

class Bubble
{
    public:
        int comp=0;
        
        void bubbleSort(int array[], int size)
        {
            for (int step = 0; step < size; ++step)
            {
                for (int i = 0; i < size - step; ++i)
                {
                    comp++;
                    if (array[i] > array[i + 1])
                    {
                        int temp = array[i];
                        array[i] = array[i + 1];
                        array[i + 1] = temp;
                    }
                }
            }
        }
};

class Shell
{
  public:
    int comp=0;
    
    void shellSort(int array[], int n) 
    {
        for (int interval = n / 2; interval > 0; interval /= 2) 
        {
            for (int i = interval; i < n; i += 1) 
            {
                int temp = array[i];
                int j;
                comp+=i;
                for (j = i; j >= interval && array[j - interval] > temp; j -= interval) 
                {
                    array[j] = array[j - interval];
                }
                array[j] = temp;
            }
        }
    }
};

class Quick
{
  public:
    int comp=0;
    
    void swap(int *a, int *b)
    {
        int t = *a;
        *a = *b;
        *b = t;
    }

    int partition(int array[], int low, int high) 
    {
        int pivot = array[high];
        int i = (low - 1);
        for (int j = low; j < high; j++) 
        {
            comp++;
            if (array[j] <= pivot) 
            {
                i++;
                swap(&array[i], &array[j]);
            }
        }
    swap(&array[i + 1], &array[high]);
    return (i + 1);
    }

    void quickSort(int array[], int low, int high)
    {
        if (low < high)
        {
            int pi = partition(array, low, high);
            quickSort(array, low, pi - 1);
            quickSort(array, pi + 1, high);
        }
    }
};

class Merge
{
  public:
    int comp=0;
  
    void merge(int arr[], int p, int q, int r) 
    {
        int n1 = q - p + 1;
        int n2 = r - q;
        int L[n1], M[n2];

        for (int i = 0; i < n1; i++)
            L[i] = arr[p + i];
        for (int j = 0; j < n2; j++)
            M[j] = arr[q + 1 + j];
        int i, j, k;
        i = 0;
        j = 0;
        k = p;
        while (i < n1 && j < n2) 
        {
            comp++;
            if (L[i] <= M[j]) 
            {
                arr[k] = L[i];
                i++;
            } 
            else
            {
                arr[k] = M[j];
                j++;
            }
            k++;
        }
        while (i < n1)
        {
            arr[k] = L[i];
            i++;
            k++;
        }
        while (j < n2)
        {
            arr[k] = M[j];
            j++;
            k++;
        }
    }

    void mergeSort(int arr[], int l, int r) 
    {
        if (l < r) 
        {
            int m = l + (r - l) / 2;
            mergeSort(arr, l, m);
            mergeSort(arr, m + 1, r);
            merge(arr, l, m, r);
        }
    }
};

class Heap
{
    public:
        int comp=0;
        
        void swap(int *a, int *b)
        {
            int temp = *a;
            *a = *b;
            *b = temp;
        }
  
        void heapify(int arr[], int n, int i)
        {
            int largest = i;
            int left = 2 * i + 1;
            int right = 2 * i + 2;
  
            comp++;
            
            if (left < n && arr[left] > arr[largest])
                largest = left;
  
            if (right < n && arr[right] > arr[largest])
                largest = right;
 
            if (largest != i)
            {
                swap(&arr[i], &arr[largest]);
                heapify(arr, n, largest);
            }
        }
  
        void heapSort(int arr[], int n) 
        {
            for (int i = n / 2 - 1; i >= 0; i--)
                heapify(arr, n, i);
 
            for (int i = n - 1; i >= 0; i--) 
            {
                swap(&arr[0], &arr[i]);
                heapify(arr, i, 0);
            }
        }
};

class Randomisedquick
{
    public:
        int comp=0;
        
        int partition(int arr[], int low, int high)
        {
            int pivot = arr[low];
            int i = low - 1, j = high + 1;
            while (true) 
            {
                do
                {
                    comp++;
                    i++;
                } 
                while (arr[i] < pivot);
            do 
            {
                comp++;
                j--;
            }
            while (arr[j] > pivot);
            
            comp++;
            if (i >= j)
                return j;
 
            swap(arr[i], arr[j]);
            }
        }
 
        int partition_r(int arr[], int low, int high)
        {
            srand(time(NULL));
            int random = low + rand() % (high - low);
            swap(arr[random], arr[low]);
            return partition(arr, low, high);
        }
 
        void quickSort(int arr[], int low, int high)
        {
            if (low < high) 
            {
                int pi = partition_r(arr, low, high);
                quickSort(arr, low, pi);
                quickSort(arr, pi + 1, high);
            }
        }
 
};

void copy(int* arr1,int* arr2,int a)
{
    for(int i=0;i<a;i++)
    {
        arr1[i]=arr2[i];
    }
}


int main()
{
    cout<<setprecision(15)<<fixed;
    clock_t start,end;
    int arr[14] = {5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 25000, 50000, 100000};
    int n;
    ofstream select("selectionsort.txt");
    ofstream insert("insertionsort.txt");
    ofstream bubble("bubblesort.txt");
    ofstream shell("shellsort.txt");
    ofstream quick("quicksort.txt");
    ofstream merge("mergesort.txt");
    ofstream heap("heapsort.txt");
    ofstream randomquick("randomisedquicksort.txt");
    select<<"N"<<"\t"<<"Average Time"<<"\t"<<"Average Count"<<endl;
    insert<<"N"<<"\t"<<"Average Time"<<"\t"<<"Average Count"<<endl;
    bubble<<"N"<<"\t"<<"Average Time"<<"\t"<<"Average Count"<<endl;
    shell<<"N"<<"\t"<<"Average Time"<<"\t"<<"Average Count"<<endl;
    quick<<"N"<<"\t"<<"Average Time"<<"\t"<<"Average Count"<<endl;
    merge<<"N"<<"\t"<<"Average Time"<<"\t"<<"Average Count"<<endl;
    heap<<"N"<<"\t"<<"Average Time"<<"\t"<<"Average Count"<<endl;
    randomquick<<"N"<<"\t"<<"Average Time"<<"\t"<<"Average Count"<<endl;
    myTimer obj;
    for(int i=0;i<14;i++)
    {
          ifstream getf("gen"+to_string(arr[i])+"_1.txt");
          int* arr1;
          int* arr2;
          arr1=new int[arr[i]];
          arr2=new int[arr[i]];
          for(int j=0;j<arr[i];j++)
          {
                getf>>n;
                arr1[j]=n;
                arr2[j]=n;
          }
          Selection obj1;
          Insertion obj2;
          Bubble obj3;
          Shell obj4;
          Quick obj5;
          Merge obj6;
          Heap obj7;
          Randomisedquick obj8;
          obj.StartTimer();
          obj1.selectionSort(arr1,arr[i]);
          obj.EndTimer();
          double interval1=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          select<<arr[i]<<"\t"<<interval1<<"\t"<<obj1.comp<<endl;
          obj.StartTimer();
          obj2.insertionSort(arr1,arr[i]);
          obj.EndTimer();
          double interval2=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          insert<<arr[i]<<"\t"<<interval2<<"\t"<<obj2.comp<<endl;
          obj.StartTimer();
          obj3.bubbleSort(arr1,arr[i]);
          obj.EndTimer();
          double interval3=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          bubble<<arr[i]<<"\t"<<interval3<<"\t"<<obj3.comp<<endl;
          obj.StartTimer();
          obj4.shellSort(arr1,arr[i]);
          obj.EndTimer();
          double interval4=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          shell<<arr[i]<<"\t"<<interval4<<"\t"<<obj4.comp<<endl;
          obj.StartTimer();
          obj5.quickSort(arr1,0,arr[i]-1);
          obj.EndTimer();
          double interval5=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          quick<<arr[i]<<"\t"<<interval5<<"\t"<<obj5.comp<<endl;
          obj.StartTimer();
          obj6.mergeSort(arr1,0,arr[i]-1);
          obj.EndTimer();
          double interval6=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          merge<<arr[i]<<"\t"<<interval6<<"\t"<<obj6.comp<<endl;
          obj.StartTimer();
          obj7.heapSort(arr1,arr[i]);
          obj.EndTimer();
          double interval7=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          heap<<arr[i]<<"\t"<<interval7<<"\t"<<obj7.comp<<endl;
          obj.StartTimer();
          obj8.quickSort(arr1,0,arr[i]-1);
          obj.EndTimer();
          double interval8=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          randomquick<<arr[i]<<"\t"<<interval8<<"\t"<<obj8.comp<<endl;
    }
    return 0;
}
