#include <iostream>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <fstream>
using namespace std;

// #ifndef MYTIMER_H_INCLUDED
// #define MYTIMER_H_INCLUDED
// #include <windows.h>
// class myTimer{
//  LARGE_INTEGER Frequency;
//  LARGE_INTEGER startTime;
//  LARGE_INTEGER endTime;
//  double interval;
// public:
//  myTimer() { QueryPerformanceFrequency(&Frequency); }
//  void StartTimer(){ QueryPerformanceCounter(&startTime); }
//  void EndTimer(){ QueryPerformanceCounter(&endTime); }
//  double GetInterval() {
//  return (double) (endTime.QuadPart - startTime.QuadPart) / Frequency.QuadPart;
//  }
// };
// #endif

#ifndef MYRANDOM_H_INCLUDED
#define MYRANDOM_H_INCLUDED
class myRandom{
 static const unsigned long a = 1664525L, c = 1664525L, m = 186423L;
 static unsigned long x;
public:
 myRandom(unsigned long s=8462817L) { x = s;}
 static void setSeed(unsigned long s){ x = s;}
 static unsigned long getVal() {return x=(a*x + c)%m;}
 static unsigned long getCurVal(){ return x;}
};
unsigned long myRandom::x = 8462817L;
#endif 

int main(int argc, char* argv[])
{
    clock_t start,end;
    if(argc!=3)
    {
        cout<<"Error\n";
        exit(1);
    }
    int p=atoi(argv[1]);
    int q=atoi(argv[2]);
    //myTimer obj1;
    //obj1.StartTimer();
    start=clock();
    int randomnum=-1;
    int a=57;
    int c=15;
    int m=13;
    while(q>0)
    {
    ofstream put("gen"+to_string(p)+"_"+to_string(q)+".txt");
    myRandom obj;
    for(int i=0;i<p;i++)
    {
        unsigned long randomnum;
        randomnum=obj.getCurVal();
        put<<randomnum<<endl;
        randomnum=obj.getVal();
    }
    q--;
    }
    //obj1.EndTimer();
    //double interval=obj1.GetInterval();
    //cout<<"Average time taken = "<<interval<<" seconds\n";
    end=clock();
    cout<<"Average time taken = "<<(double)(end-start)/CLOCKS_PER_SEC<<" seconds\n";
}
