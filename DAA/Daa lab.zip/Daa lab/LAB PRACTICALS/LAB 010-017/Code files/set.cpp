#ifndef MYSET_H_INCLUDED
#define MYSET_H_INCLUDED
#include "myList.h"
#include <sstream>
template <class T>
class mySet; // Forward reference

template <class T>
mySet<T> operator + ( mySet<T>&a,  mySet<T>&b); // Forward reference

template <class T>
mySet<T> operator - ( mySet<T>&a,  mySet<T>&b); // Forward reference

template <class T>
mySet<T> operator * ( mySet<T>&a,  mySet<T>&b); // Forward reference

template <class T>
class mySet: public myList<T> {
private:
    //myList functions not accessible to instances of mySet
public:
    mySet():myList<T>() {}
    mySet(T x):myList<T>(x) {}
    mySet(const T* x, long Size);
    mySet(mySet<T>& x):myList<T>(x) {}
    ~mySet(){Clear();}

    using myList<T>::First;
    using myList<T>::Last;
    using myList<T>::isEmpty;
    using myList<T>::SizeOf;
    using myList<T>::Contains;
    using myList<T>::Clear;
    using myList<T>::Remove;
    Node<T>* addLast(T x);

    string Name() {
        if (myList<T>::H.Size == 0) return "PHI";
        else{
            ostringstream ss;
            ss << myList<T>::H.Front->Data;
            return ss.str();
        }
    }

    friend mySet<T> operator + <>( mySet<T>&a,  mySet<T>&b);
    mySet<T> operator += (T x);
    mySet<T> operator += (mySet<T> x);

    mySet<T> operator -= (T x);
    mySet<T> operator -= (mySet<T> x);
    friend mySet<T> operator - <>( mySet<T>&a,  mySet<T>&b);

    mySet<T> operator *= (mySet<T> x);
    friend mySet<T> operator * <>( mySet<T>&a,  mySet<T>&b);
};

/* ********************************************************* */
/* Implementation                                            */
/* ********************************************************* */
template <class T>
mySet<T>::mySet(const T* x, long Size):myList<T>(){
    for (long i = 0; i< Size; i++) addLast(x[i]);
}

template <class T>
Node<T>* mySet<T>::addLast(T x) {
    if (Contains(x)) return NULL;

    Node<T> *t = new Node<T>;
    if (!t) {
        cout << "5. Memory Allocation Error.\n";
        exit(1);
    }

    if (myList<T>::H.Front == NULL) myList<T>::H.Front = t;
    else myList<T>::H.Tail->Next = t;

    t->Parent = &(myList<T>::H);
    t->Data = x;
    t->Next = NULL;
    myList<T>::H.Tail = t;
    myList<T>::H.Size++;
    return t;
}

template <class T>
mySet<T> mySet<T>::operator += (T x) {
    addLast(x);
    return *this;
}

template <class T>
mySet<T> mySet<T>::operator += (mySet<T> x){
    Node<T> *t = myList<T>::H.Front;
    while (t) {
        addLast(t->Data);
        t = t->Next;
    }
    return *this;
}

template <class T>
mySet<T> mySet<T>::operator -= (T x){
    if (Contains(x)) Remove(x);
    return *this;
}

template <class T>
mySet<T> mySet<T>::operator -= (mySet<T> x){
    Node<T> *t = x.H.Front;
    while (t) {
        if (Contains(t->Data)) Remove(t->Data);
        t = t->Next;
    }
    return *this;
}

template <class T>
mySet<T> mySet<T>::operator *= (mySet<T> x){
    mySet<T> c(*this);
    Node<T> *t = c.H.Front;
    while(t) {
        if (!x.Contains(t->Data)) Remove(t->Data);
        t = t->Next;
    }
    return *this;
}

/* FRIENDS */
template <class T>
mySet<T> operator - ( mySet<T>&a,  mySet<T>&b){
    mySet<T> c(a);
    c -= b;
    return c;
}

template <class T>
mySet<T> operator + ( mySet<T>&a,  mySet<T>&b){
    mySet<T> c;
    Node<T> *t;
    if (a.SizeOf() > b.SizeOf()) {
        c = a;
        t = b.H.Front;
    }
    else {
        c = b;
        t = a.H.Front;
    }
    while(t) {
        if (!a.Contains(t->Data)) c.addLast(t->Data);
        t= t->Next;
    }
    return c;
}

template <class T>
mySet<T> operator * ( mySet<T>&a,  mySet<T>&b){
    mySet<T> c,d;
    Node<T> *t;
    if (a.SizeOf() > b.SizeOf()) {
        c = a;
        t = b.H.Front;
    }
    else {
        c = b;
        t = a.H.Front;
    }
    while(t) {
        if (a.Contains(t->Data)) d.addLast(t->Data);
        t= t->Next;
    }
    return d;
}
#endif // MYSET_H_INCLUDED
/* ******************************************************************** */
// And the driver file for showcasing the implementation:
/* ***************************************************** */
/* FILE: main.cpp                                        */
/* ***************************************************** */
int main() {
    {
        mySet<int> L;
        cout << "1. L= " << L;
        L.addLast(1);
        cout << "2. L= " << L;

        L.addLast(2);
        L.addLast(3);
        L.addLast(4);
        L.addLast(5);
        cout << "3. L= " << L;
        //L.addLast(5);
        //cout << "4. L= " << L;
        //L += 5;
        //cout << "5. L= " << L;
        L+=6;
        cout << "6. L= " << L;
        mySet<int> R(-1);
        cout << "7. R=" << R;
        mySet<int> S(L);
        cout << "8. S=" << S;
        S -= 1;
        cout << "9. S=" << S;
        R -= S;
        cout << "10. L=" << R;
    }




/* ************************************ */
    {
        int a[] = {1,2,3,4}, b[] = {2,3,4,5};
        mySet<int> L(a,4),R(b,4);
        cout << "11. L=" << L;
        cout << "12. R=" << R;
        L *= R;
        cout << "13. L=" << L;
        mySet<int> S;
        S = L * R;
        cout << "14. S=" << S;
        cout << "15. S=" << S.Name() << endl;
        S -= 2;
        cout << "16. S=" << S;
        S += 2;
        cout << "17. S=" << S;
        cout << "18. S=" << S.Name()<<endl;
    }
    return 0;
}
/* ***************************************************** */
