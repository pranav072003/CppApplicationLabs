#include <iostream>
#include <math.h>
using namespace std;

//FILE: myAuxFunctions.h
#ifndef MYAUXFUNCTIONS_H_INCLUDED
#define MYAUXFUNCTIONS_H_INCLUDED
unsigned long StrToULong(char* x);
#endif // MYAUXFUNCTIONS_H_INCLUDED

int main()
{
    char* p="1";
    unsigned long number=StrToULong(p);
    cout<<number;

    return 0;
}


unsigned long StrToULong(char* x)
{
    char* p;
    p=x;
    int len=0;
    while(*p!='\0')
    {
        len++;
        p++;
    }
    int idx=len;
    char* u;
    u=x;
    unsigned long v=0L;
    while(*u!='\0')
    {
        v+=(unsigned long)(((int)*u)*pow(10,idx-1));
        idx--;
        u++;
    }
    return v;
}
