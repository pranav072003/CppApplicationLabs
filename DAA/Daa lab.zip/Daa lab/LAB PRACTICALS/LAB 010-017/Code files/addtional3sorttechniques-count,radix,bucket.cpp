#include <iostream>
#include <fstream>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <iomanip>
#include <cstdlib>
using namespace std;

#ifndef MYTIMER_H_INCLUDED
#define MYTIMER_H_INCLUDED
#include <windows.h>
class myTimer{
 LARGE_INTEGER Frequency;
 LARGE_INTEGER startTime;
 LARGE_INTEGER endTime;
 double interval;
public:
 myTimer() { QueryPerformanceFrequency(&Frequency); }
 void StartTimer(){ QueryPerformanceCounter(&startTime); }
 void EndTimer(){ QueryPerformanceCounter(&endTime); }
 double GetInterval() {
 return (double) (endTime.QuadPart - startTime.QuadPart) / Frequency.QuadPart;
 }
};
#endif

class Count 
{
    public:
        int getMax(int a[], int n)
        {  
            int max = a[0];  
            for(int i = 1; i<n; i++)
            {  
                if(a[i] > max)  
                    max = a[i];  
            }  
            return max;
        }
        
        void countSort(int array[], int size) 
        {
            int m=getMax(array,size);
            int output[size];
            int* count=new int[m+1];
            int max = array[0];

            for (int i = 1; i < size; i++)
            {
                if (array[i] > max)
                    max = array[i];
            }

            // Initialize count array with all zeros.
            for (int i = 0; i <= max; ++i)
            {
                count[i] = 0;
            }

            // Store the count of each element
            for (int i = 0; i < size; i++) 
            {
                count[array[i]]++;
            }

            // Store the cummulative count of each array
            for (int i = 1; i <= max; i++)
            {
                count[i] += count[i - 1];
            }

            for (int i = size - 1; i >= 0; i--)
            {
                output[count[array[i]] - 1] = array[i];
                count[array[i]]--;
            }

            for (int i = 0; i < size; i++)
            {
                array[i] = output[i];
            }
        }
};

class Radix 
{
   public:
        int getMax(int array[], int n)
        {
            int max = array[0];
            for (int i = 1; i < n; i++)
                if (array[i] > max)
                    max = array[i];
            return max;
        }

        // Using counting sort to sort the elements in the basis of significant places
        void countingSort(int array[], int size, int place)
        {
            const int max = 20;
            int output[size];
            int count[max];

            for (int i = 0; i < max; ++i)
                count[i] = 0;

            // Calculate count of elements
            for (int i = 0; i < size; i++)
                count[(array[i] / place) % 10]++;

            // Calculate cumulative count
            for (int i = 1; i < max; i++)
                count[i] += count[i - 1];

            // Place the elements in sorted order
            for (int i = size - 1; i >= 0; i--)
            {
                output[count[(array[i] / place) % 10] - 1] = array[i];
                count[(array[i] / place) % 10]--;
            }

            for (int i = 0; i < size; i++)
            array[i] = output[i];
        }

        // Main function to implement radix sort
        void radixsort(int array[], int size)
        {
            // Get maximum element
            int max = getMax(array, size);

            // Apply counting sort to sort elements based on place value.
            for (int place = 1; max / place > 0; place *= 10)
                countingSort(array, size, place);
        }
};

class Bucket 
{
    public:
        int getMax(int a[], int n) 
        // function to get maximum element from the given array  
        {  
            int max = a[0];  
            for (int i = 1; i < n; i++)  
            if (a[i] > max)  
                max = a[i];  
            return max;  
        }
        
        void bucket(int a[], int n) // function to implement bucket sort  
        {  
            int max = getMax(a, n); //max is the maximum element of array  
            int *bucket, i;
            bucket=new int[max];
            for (int i = 0; i <= max; i++)  
            {  
                bucket[i] = 0;  
            }  
            for (int i = 0; i < n; i++)  
            {  
                bucket[a[i]]++;  
            }  
            for (int i = 0, j = 0; i <= max; i++)  
            {  
                while (bucket[i] > 0)  
                {  
                    a[j++] = i;  
                    bucket[i]--;  
                }  
            }  
        }  
};

void copy(int* arr1,int* arr2,int a)
{
    for(int i=0;i<a;i++)
    {
        arr1[i]=arr2[i];
    }
}

int main()
{
    cout<<setprecision(15)<<fixed;
    clock_t start,end;
    int arr[14] = {5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 25000, 50000, 100000};
    int n;
    ofstream count("countsort.txt");
    ofstream radix("radixsort.txt");
    ofstream bucket("bucketsort.txt");
    count<<"N"<<"\t"<<"Average Time"<<endl;
    radix<<"N"<<"\t"<<"Average Time"<<endl;
    bucket<<"N"<<"\t"<<"Average Time"<<endl;
    myTimer obj;
    Count obj1;
    Radix obj2;
    Bucket obj3;
    for(int i=0;i<14;i++)
    {
          ifstream getf("gen"+to_string(arr[i])+"_1.txt");
          int* arr1;
          int* arr2;
          arr1=new int[arr[i]];
          arr2=new int[arr[i]];
          for(int j=0;j<arr[i];j++)
          {
                getf>>n;
                arr1[j]=n;
                arr2[j]=n;
          }
          obj.StartTimer();
          obj1.countSort(arr1,arr[i]);
          obj.EndTimer();
          double interval1=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          count<<arr[i]<<"\t"<<interval1<<endl;
          
          obj.StartTimer();
          obj2.radixsort(arr1,arr[i]);
          obj.EndTimer();
          double interval2=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          radix<<arr[i]<<"\t"<<interval2<<endl;
          
          obj.StartTimer();
          obj3.bucket(arr1,arr[i]);
          obj.EndTimer();
          double interval3=obj.GetInterval();
          copy(arr1,arr2,arr[i]);
          bucket<<arr[i]<<"\t"<<interval3<<endl;
    }
    
    return 0;
}
