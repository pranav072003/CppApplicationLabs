#include <iostream>
#include <fstream>
#include <math.h>
#include <time.h>
#include <unistd.h>
#include <iomanip>
#include <cstdlib>
using namespace std;

#ifndef MYTIMER_H_INCLUDED
#define MYTIMER_H_INCLUDED
#include <windows.h>
class myTimer{
 LARGE_INTEGER Frequency;
 LARGE_INTEGER startTime;
 LARGE_INTEGER endTime;
 double interval;
public:
 myTimer() { QueryPerformanceFrequency(&Frequency); }
 void StartTimer(){ QueryPerformanceCounter(&startTime); }
 void EndTimer(){ QueryPerformanceCounter(&endTime); }
 double GetInterval() {
 return (double) (endTime.QuadPart - startTime.QuadPart) / Frequency.QuadPart;
 }
};
#endif

// function to swap elements
void swap(int *a, int *b) {
  int t = *a;
  *a = *b;
  *b = t;
}

// function to print the array
void printArray(int array[], int size) {
  int i;
  for (i = 0; i < size; i++)
    cout << array[i] << " ";
  cout << endl;
}

// function to rearrange array (find the partition point)
int partition(int array[], int low, int high) {
    
  // select the rightmost element as pivot
  int pivot = array[high];
  
  // pointer for greater element
  int i = (low - 1);

  // traverse each element of the array
  // compare them with the pivot
  for (int j = low; j < high; j++) {
    if (array[j] <= pivot) {
        
      // if element smaller than pivot is found
      // swap it with the greater element pointed by i
      i++;
      
      // swap element at i with element at j
      swap(&array[i], &array[j]);
    }
  }
  
  // swap pivot with the greater element at i
  swap(&array[i + 1], &array[high]);
  
  // return the partition point
  return (i + 1);
}

class Min 
{
    public:
        int getMin(int array[],int size)
        {
            int part=partition(array,0,size-1);
            while(part!=0)
            {
                part=partition(array,0,part-1);
            }
            return array[part];
        }
};

class Max 
{
    public:
        int getMax(int array[],int size)
        {
            int part=partition(array,0,size-1);
            while(part!=(size-1))
            {
                part=partition(array,part+1,size-1);
            }
            return array[part];
        }
};

class MinMax 
{
    public:
        int comp=0;
    
        int getMinMax(int array[],int size)
        {
            int part=partition(array,0,size-1);
            int temp=part;
            while(part!=0)
            {
                part=partition(array,0,part-1);
                comp++;
            }
            while(temp!=(size-1))
            {
                temp=partition(array,temp+1,size-1);
                comp++;
            }
            return array[temp];
        }
};

class ith 
{
    public:
        int comp=0;
    
        int getithsmall(int array[],int size,int idx=4)
        {
            int part=partition(array,0,size-1);
            while(part!=idx)
            {
                if(part==idx)
                {
                    break;
                }
                else if(part>idx)
                part=partition(array,0,part-1); 
                else
                part=partition(array,part+1,size-1);
                comp++;
            }
            return array[part];
        }
};

// Driver code
int main()
{
    cout<<setprecision(15)<<fixed;
    clock_t start,end;
    int arr[14] = {5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 25000, 50000, 100000};
    int n;
    ofstream min("minelement.txt");
    ofstream max("maxelement.txt");
    ofstream minmax("minmaxelement.txt");
    ofstream ithsmall("ithsmallestelement.txt");
    min<<"N"<<"\t"<<"Average Time"<<endl;
    max<<"N"<<"\t"<<"Average Time"<<endl;
    minmax<<"N"<<"\t"<<"Average Time"<<"\t"<<"Avg no. of Comparisons"<<endl;
    ithsmall<<"N"<<"\t"<<"Average Time"<<"\t"<<"Avg no. of Comparisons"<<endl;
    myTimer obj;
    Min obj1;
    Max obj2;
    MinMax obj3;
    ith obj4;
    for(int i=0;i<14;i++)
    {
          ifstream getf("gen"+to_string(arr[i])+"_1.txt");
          int* arr1;
          arr1=new int[arr[i]];
          for(int j=0;j<arr[i];j++)
          {
                getf>>n;
                arr1[j]=n;
          }
          obj.StartTimer();
          int minimum=obj1.getMin(arr1,arr[i]);
          obj.EndTimer();
          double interval1=obj.GetInterval();
          min<<arr[i]<<"\t"<<interval1<<endl;
          
          obj.StartTimer();
          int maxa=obj2.getMax(arr1,arr[i]);
          obj.EndTimer();
          double interval2=obj.GetInterval();
          max<<arr[i]<<"\t"<<interval2<<endl;
          
          obj.StartTimer();
          int maxb=obj3.getMinMax(arr1,arr[i]);
          obj.EndTimer();
          double interval3=obj.GetInterval();
          minmax<<arr[i]<<"\t"<<interval3<<"\t"<<obj3.comp<<endl;
          
          obj.StartTimer();
          int imin=obj4.getithsmall(arr1,arr[i]);
          obj.EndTimer();
          double interval4=obj.GetInterval();
          ithsmall<<arr[i]<<"\t"<<interval4<<"\t"<<obj4.comp<<endl;
    }
    return 0;
}