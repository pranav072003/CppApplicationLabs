#include <iostream>
#include <vector>

class Knapsack
{
private:
    struct Item
    {
        int weight;
        int value;
    };

    std::vector<Item> items;
    int capacity;
    int max_value;
    std::vector<int> optimal_items;

public:
    Knapsack(int capacity) : capacity(capacity), max_value(0) {}

    void addItem(int weight, int value)
    {
        Item item;
        item.weight = weight;
        item.value = value;
        items.push_back(item);
    }

    void bruteForce(int current_value, int current_weight, int index, std::vector<int> chosen_items)
    {
        if (current_weight > capacity)
            return;

        if (index == items.size())
        {
            if (current_value > max_value)
            {
                max_value = current_value;
                optimal_items = chosen_items;
            }
            return;
        }

        // Exclude current item
        bruteForce(current_value, current_weight, index + 1, chosen_items);

        // Include current item
        chosen_items.push_back(index);
        bruteForce(current_value + items[index].value, current_weight + items[index].weight, index + 1, chosen_items);
    }

    int getMaxValue()
    {
        bruteForce(0, 0, 0, {});
        return max_value;
    }

    std::vector<int> getOptimalItems()
    {
        return optimal_items;
    }
};

int main()
{
    Knapsack knapsack(8);
    knapsack.addItem(2, 3);
    knapsack.addItem(3, 4);
    knapsack.addItem(4, 5);
    knapsack.addItem(5, 6);

    int maxValue = knapsack.getMaxValue();
    std::vector<int> optimalItems = knapsack.getOptimalItems();

    std::cout << "Max value: " << maxValue << std::endl;
    std::cout << "Optimal items index: ";
    for (int itemIndex : optimalItems)
    {
        std::cout << itemIndex << " ";
    }
    std::cout << std::endl;

    return 0;
}
