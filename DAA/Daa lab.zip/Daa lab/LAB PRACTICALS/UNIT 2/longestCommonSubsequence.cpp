#include <iostream>
#include <vector>
#include <algorithm>

class LCS
{
private:
    std::string str1;
    std::string str2;
    std::vector<std::vector<int>> dp;

public:
    LCS(const std::string &s1, const std::string &s2) : str1(s1), str2(s2)
    {
        dp.resize(str1.size() + 1, std::vector<int>(str2.size() + 1, -1));
    }

    int lcsRecursive(int i, int j)
    {
        if (i == 0 || j == 0)
            return 0;

        if (dp[i][j] != -1)
            return dp[i][j];

        if (str1[i - 1] == str2[j - 1])
            dp[i][j] = 1 + lcsRecursive(i - 1, j - 1);
        else
            dp[i][j] = std::max(lcsRecursive(i - 1, j), lcsRecursive(i, j - 1));

        return dp[i][j];
    }

    int lcsMemoized(int i, int j)
    {
        if (i == 0 || j == 0)
            return 0;

        if (dp[i][j] != -1)
            return dp[i][j];

        if (str1[i - 1] == str2[j - 1])
            dp[i][j] = 1 + lcsMemoized(i - 1, j - 1);
        else
            dp[i][j] = std::max(lcsMemoized(i - 1, j), lcsMemoized(i, j - 1));

        return dp[i][j];
    }

    int lcsBottomUp()
    {
        int m = str1.size();
        int n = str2.size();
        std::vector<std::vector<int>> dp(m + 1, std::vector<int>(n + 1, 0));

        for (int i = 1; i <= m; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                if (str1[i - 1] == str2[j - 1])
                    dp[i][j] = 1 + dp[i - 1][j - 1];
                else
                    dp[i][j] = std::max(dp[i - 1][j], dp[i][j - 1]);
            }
        }

        return dp[m][n];
    }

    std::string getLCS()
    {
        int m = str1.size();
        int n = str2.size();
        std::vector<std::vector<int>> dp(m + 1, std::vector<int>(n + 1, 0));

        for (int i = 1; i <= m; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                if (str1[i - 1] == str2[j - 1])
                    dp[i][j] = 1 + dp[i - 1][j - 1];
                else
                    dp[i][j] = std::max(dp[i - 1][j], dp[i][j - 1]);
            }
        }

        std::string lcs;
        int i = m, j = n;
        while (i > 0 && j > 0)
        {
            if (str1[i - 1] == str2[j - 1])
            {
                lcs += str1[i - 1];
                i--;
                j--;
            }
            else if (dp[i - 1][j] > dp[i][j - 1])
            {
                i--;
            }
            else
            {
                j--;
            }
        }
        std::reverse(lcs.begin(), lcs.end());

        return lcs;
    }
};

int main()
{
    std::string s1, s2;

    // Input the two strings
    std::cout << "Enter the first string: ";
    std::cin >> s1;
    std::cout << "Enter the second string: ";
    std::cin >> s2;

    LCS lcs(s1, s2);

    // Recursive approach
    int lcsRecursive = lcs.lcsRecursive(s1.size(), s2.size());
    std::cout << "Recursive Approach - LCS Length: " << lcsRecursive << std::endl;

    // Memoized approach
    int lcsMemoized = lcs.lcsMemoized(s1.size(), s2.size());
    std::cout << "Memoized Approach - LCS Length: " << lcsMemoized << std::endl;

    // Bottom-up approach
    int lcsBottomUp = lcs.lcsBottomUp();
    std::cout << "Bottom-up Approach - LCS Length: " << lcsBottomUp << std::endl;

    // LCS string
    std::string longestCommonSubsequence = lcs.getLCS();
    std::cout << "Longest Common Subsequence: " << longestCommonSubsequence << std::endl;

    return 0;
}
