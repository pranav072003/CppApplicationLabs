#ifndef MYARRAY_H_INCLUDED
#define MYARRAY_H_INCLUDED
#include <iostream>
#include <ostream>
#include <string>
#include <math.h>
//#include "myException.h"

long int INT_MAX=pow(2,16);
long int LONG_MAX=INT_MAX;

/* ********************************************************************************** */
/* For proper usage these class typename T should be one of the numeric data types    */
/* Usage with other datatypes is fraught with inconvenience. For non-numeric datatype */
/* Use AT YOUR OWN RISK.                                                              */
/* ********************************************************************************** */
using namespace std;

//Forward declarations
template <class T>
class myArray;

template <class T>
class myArray {
    T *D; //Data
    int S; //Size
    /* ****************************************************************************** */
    /* A private function for allocation of memory                                    */
    /* ****************************************************************************** */
    void Allocate(int N) {
        D = new T[S=N];
        //if (!D) throw myException("myArray:Memory initialization failed\n");
    }

public:
    /* ****************************************************************************** */
    /* CONSTRUCTOR(S)                                                                 */
    /* ****************************************************************************** */

    myArray<T>(){ D = NULL; S = -1;} //noninitialized array

    myArray<T>(unsigned int Size) {
        Allocate(int(Size));
        for (int i = 0; i < S; i++) D[i] =T(0);
    }

    myArray<T>(T *d, unsigned int Size) {
        Allocate(int(Size));
        for (int i = 0; i < S; i++) D[i] =d[i];
    }

    myArray<T>(const myArray<T>& A) {
        Allocate(A.S);
        for (int i = 0; i < S; i++) D[i] =A.D[i];
    }

    /* ****************************************************************************** */
    /* DESTRUCTOR                                                                     */
    /* ****************************************************************************** */
    virtual ~myArray(){ Clear(); }

    /* ****************************************************************************** */
    /* Auxiliary functions but useful                                                 */
    /* ****************************************************************************** */
    bool isEmpty() { return S == -1;} // If data exists false else true
    int Size() {if (S < 0) return 0;  return S;} // Number of data items put in array
    void Clear(){ delete [] D; S = -1; D = NULL;} // Truncates the array

    /* ****************************************************************************** */
    /* OPERATOR OVERLOADING                                                           */
    /* ****************************************************************************** */
    T& operator[] (int i){ //Access by index (zero based)
        if (i > -1 && i < S) return D[i];
        //throw myException("myArray: Out of range access\n");
    }

    myArray<T>& operator = (myArray<T> x){ //asignment
        //if (x.Size() <= 0) throw myException("myArray: Assigning non initialized array\n");
        Clear();
        Allocate(x.S);
        for (int i = 0; i < S; i++) D[i] = x.D[i];
        return *this;
    }

    myArray<T>& operator - () { //unary -
        //if (Size() <= 0) throw myException("myArray: negative of unassigned array\n");
        myArray<T> x(*this);
        for (int i = 0; i < S; i++) x[i] = -x[i];
        return x;
    }

    myArray<T>& operator + () {//unary +
        //if (Size() <= 0) throw myException("myArray: negative of unassigned array\n");
        myArray<T> x(*this);
        return x;
    }

    myArray<T>& operator += (myArray<T> x){ //add + assignement
        //if (x.Size() != Size()) throw myException("myArray +: Different sized array\n");
        for (int i = 0; i < x.Size(); i++) D[i] += x[i];
        return *this;
    }

    friend myArray<T> operator + (myArray<T> x, myArray<T> y){ //addition
        //if (x.Size() != y.Size()) throw myException("myArray +: Different sized array\n");
        myArray<T> z(x.Size());
        for (int i = 0; i < x.Size(); i++) z[i] = x[i] + y[i];
        return z;
    }

    myArray<T>& operator -= (myArray<T> x){ //subtract and assign
        //if (x.Size() != Size()) throw myException("myArray +: Different sized array\n");
        for (int i = 0; i < x.Size(); i++) D[i] -= x[i];
        return *this;
    }

    friend myArray<T> operator - (myArray<T> x, myArray<T> y){ //subtract
        //if (x.Size() != y.Size()) throw myException("myArray +: Different sized array\n");
        myArray<T> z(x.Size());
        for (int i = 0; i < x.Size(); i++) z[i] = x[i] - y[i];
        return z;
    }

    friend T operator %  (myArray<T> x, myArray<T> y){ //dot product
        //if (x.Size() != y.Size()) throw myException("myArray +: Different sized array\n");
        T z= T(0);
        for (int i = 0; i < x.Size(); i++) z += x[i] * y[i];
        return z;
    }

    friend myArray<T> operator * (myArray<T> a, T x){ //multiply by a constant
        //if (a.Size() <= 0) throw myException("myArray: negative of unassigned array\n");
        myArray<T> y(a);
        for (int i = 0; i < y.Size(); i++) y[i] = a[i] * x;
        return y;
    }

    friend myArray<T> operator * (T x, myArray<T> a){ //multiply by a constant
        return a * x;
    }

    //OUTPUT STREAM OVERLOAD. NOT A VERY TRICKY FUNCTION
    friend std::ostream& operator << (std::ostream& os, myArray<T> x){
        if (x.Size() <= 0) return os << "{ Null }";
        for (int i = 0; i < x.Size() - 1; i++ ) os << x[i] << " ";
        return os << x[x.Size() - 1];
    }

    //OUTPUT in a slighly formatted manner
    void Print(std::ostream& os=std::cout ){
        if (Size() <= 0) {os << "{ Null }"; return;}
        os << "{ ";
        for (int i = 0; i < Size()-1; i++ ) os << D[i] << " ";
        os << D[Size() - 1] << " }";
    }

    // Read an array. The size of the array is fixed before reading
    friend std::istream& operator >> (std::istream& Input, myArray<T>& x){
        int n=x.S;
        for (int i = 0; i< n; i++) Input >> x[i];
        return Input;
    }

};

#endif // MYARRAY_H_INCLUDED

class myRandom{
    static const unsigned long a = 1664525L, c = 1664525L;
    static unsigned long x;

public:
    myRandom(unsigned long s=8462817L) { x = s;}
    static void setSeed(unsigned long s){ x = s;}
    static unsigned long getVal() { return x = a*x + c;}
    static unsigned long getCurVal(){ return x;}
};
unsigned long myRandom::x = 8462817L;

template <class T>
class Matrix{
    myArray<T> *D; //Data
    int M,N; //Size
    /* ****************************************************************************** */
    /* A private function for allocation of memory                                    */
    /* ****************************************************************************** */
    void Allocate(int m, int n) {
        M = m;
        N = n;
        D = new myArray<T>[M];
        for (int i = 0; i < M; i++) D[i] = myArray<T>(N);
        //if (!D) throw myException("Matrix:Memory initialization failed\n");
    }

public:
    /* ****************************************************************************** */
    /* CONSTRUCTOR(S)                                                                 */
    /* ****************************************************************************** */

    Matrix<T>(){ D = NULL; M = -1;} //noninitialized array

    Matrix<T>(unsigned int m, unsigned n){ Allocate(int(m),int(n)); }

    Matrix<T>(T *d,unsigned int m, unsigned n):M(m), N(n) {
        Allocate(int(m),int(n));
        for (int i = 0; i < M; i++)
            for (int j = 0; j < N; j++)
                D[i][j] = *((d+i*n) + j);
    }

    Matrix<T>(const Matrix<T>& A) {
        D = new myArray<T>[M = A.M];
        N = A.N;
        //if (!D) throw myException("Matrix: Memory initialization failed\n");
        for (int i = 0; i < M; i++) D[i] = A.D[i];
    }

    /* ****************************************************************************** */
    /* DESTRUCTOR                                                                     */
    /* ****************************************************************************** */
    ~Matrix(){ Clear(); }

    /* ****************************************************************************** */
    /* Auxiliary functions but useful                                                 */
    /* ****************************************************************************** */
    bool isEmpty() { return M == -1;}
    int Rows() {if (M < 0) return 0; return M;}
    int Cols() {if (M < 0) return 0; return D[0].Size();}
    void Clear(){ delete [] D; M = -1; D = NULL;}

    /* ****************************************************************************** */
    /* OPERATOR OVERLOADING                                                           */
    /* ****************************************************************************** */
    myArray<T>& operator[] (int i){ //Access by index
        if (i > -1 && i < M) return D[i];
        //throw myException("Matrix: Out of range access\n");
    }

    friend std::ostream& operator << (std::ostream& os, Matrix<T> x) { // OUTPUT, not very well formatted
        if (x.M<0) return os << "0 0";
        else os << x.M << " " << x.N << " ";
        for (int i = 0; i < x.M ; i++) os << x.D[i] << " ";
        return os;// << x.D[x.M - 1];
    }

    void Print(std::ostream& os=std::cout) { // OUTPUT, slightly formatted
        if (M<0) {os << "{ NULL }"; return;}
        else os << "{ " << M << ", " << N << " }";
        for (int i = 0; i < M; i++) D[i].Print(os);
    }

    Matrix<T>& operator = (Matrix<T> x){ //asignment
        //if (x.M <= 0 || x.N <= 0) throw myException("Matrix 01: Assigning non initialized matrix\n");
        Clear();
        Allocate(x.M,x.N);
        for (int i = 0; i < M; i++) D[i] = x.D[i];
        return *this;
    }

    Matrix<T>& operator - () { //unary -
        //if (M <= 0 || N <= 0) throw myException("Matrix 02: non initialized matrix\n");
        Matrix<T> x(*this);
        for (int i = 0; i < M; i++) x.D[i] = -D[i];
        return x;
    }

    Matrix<T>& operator + () {//unary +
        //if (M <= 0 || N <= 0) throw myException("Matrix 03: non initialized matrix\n");
        myArray<T> x(*this);
        return x;
    }

    Matrix<T>& operator += (Matrix<T> x){ //add + assignment
        //if (x.M !=M || x.N != N) throw myException("Matrix 04: Adding incompatible matrix\n");
        for (int i = 0; i < x.M; i++) D[i] += x[i];
        return *this;
    }

    friend Matrix<T> operator + (Matrix<T> x, Matrix<T> y){ //addition
        //if (x.M !=y.M || x.N != y.N) throw myException("Matrix 05: Adding incompatible matrix\n");
        Matrix<T> z(x);
        for (int i = 0; i < x.M; i++) z.D[i] = x.D[i] + y.D[i];
        return z;
    }

    Matrix<T>& operator -= (Matrix<T> x){ //subtract and assign
        //if (x.M !=M || x.N != N) throw myException("Matrix 06: Subtracting incompatible matrix\n");
        for (int i = 0; i < x.M; i++) D[i] -= x.D[i];
        return *this;
    }

    friend Matrix<T> operator - (Matrix<T> x, Matrix<T> y){ //subtract
        //if (x.M !=y.M || x.N != y.N) throw myException("Matrix 07: Subtracting incompatible matrix\n");
        Matrix<T> z(x);
        for (int i = 0; i < x.M; i++) z.D[i] = x.D[i] - y.D[i];
        return z;
    }

    friend Matrix<T> operator % (Matrix<T> x, Matrix<T> y){ //Term * Term multiplication
        //if (x.M !=y.M || x.N != y.N) throw myException("Matrix 08: Incompatible matrix\n");
        Matrix<T> z(x);
        for (int i = 0; i < x.M; i++)
            for (int j = 0; j < x.N; j++)
                z[i][j] = x[i][j] * y[i][j];
        return z;
    }

    friend Matrix<T> operator * (Matrix<T> a, T x){ //multiply by a scaler
        //if (a.M <= 0 || a.N <= 0) throw myException("Matrix 09: non initialized matrix\n");
        Matrix<T> y(a);
        for (int i = 0; i < y.M; i++) y.D[i] = a.D[i] * x;
        return y;
    }

    friend Matrix<T> operator * (T x, Matrix<T> a){ //multiply by a scaler
        return a * x;
    }

    friend Matrix<T> operator * (Matrix<T> a, Matrix<T> b){//multiply
        //if (a.N != b.M ) throw myException("Matrix 11: Incompatible matrix\n");
        Matrix<T> y(a.M,b.N);
        for (int i = 0; i < y.M; i++)
            for (int j = 0; j < y.N; j++)
                for (int k = 0; k < a.N; k++) y[i][j] += a[i][k] * b[k][j];
        return y;
    }

    Matrix<T>& operator *= (Matrix<T> b){//multiply and assign
        //if (N != b.M ) throw myException("Matrix 10: Incompatible matrix\n");
        Matrix<T> y(M,b.N);
        for (int i = 0; i < y.M; i++)
            for (int j = 0; j < y.N; j++)
                for (int k = 0; k < N; k++) y[i][j] += D[i][k] * b[k][j];
        *this = y;
        return *this;
    }

    Matrix<T> operator ~ (){//Transpose
        if (M <= 0 || N <= 0) return Matrix<T>();
        Matrix<T> y(N,M);
        for (int i = 0; i < M; i++)
            for (int j = 0; j < N; j++) y[j][i] += D[i][j];
        return y;
    }

    friend std::istream& operator >> (std::istream& Input, Matrix<T>& x){ //read a matrix, first 2 elements are the size parameters ROWS COLS
        x.Clear();
        int m,n;
        Input >> m >> n;
        x.Allocate(m,n);
        for (int i = 0; i< m; i++) Input >> x[i];
        return Input;
    }
};
myRandom R;
template <typename T>
Matrix<T> RandomMatrix(const int M, const int N, long MAX = 0){
    Matrix<T> x(M,N);
    unsigned long V;
    for (int i = 0; i < M; i++){
        for (int j = 0; j < N; j++) {
            V = R.getVal();
            if (std::is_same<T,double>::value || std::is_same<T,float>::value) x[i][j] = (V / double(4294967295LL));
            else if (std::is_same<T,int>::value) x[i][j] = V - long(V/INT_MAX)*INT_MAX;
            else if (std::is_same<T,long>::value) x[i][j] = V - long(V/LONG_MAX)*LONG_MAX;
            if (MAX) {
                if (std::is_same<T,double>::value || std::is_same<T,float>::value) x[i][j] *= MAX;
                else x[i][j] -= long(x[i][j]/MAX)*MAX;
            }
        }
    }
    return x;
}
int main() {
    //Creates a set of matrices
    Matrix<int> A, B, C;
    Matrix<long> D, E, F;
    Matrix<double> G, H, I;

    //INITIALIZE BY INVOKING RANDOMMATRIX
    A = RandomMatrix<int>(3,3,2);
    B = RandomMatrix<int>(3,3,5);
    C = RandomMatrix<int>(3,3,10);

    D = RandomMatrix<long>(3,3,4);
    E = RandomMatrix<long>(3,3,6);
    F = RandomMatrix<long>(3,3,8);

    G = RandomMatrix<double>(3,3,4);
    H = RandomMatrix<double>(3,3,1);
    I = RandomMatrix<double>(3,3,2);

    //PRINT THEM OUT
    cout << "A = "; A.Print(); cout << endl;
    cout << "B = "; B.Print(); cout << endl;
    cout << "C = "; C.Print(); cout << endl;

    //PRINT THEM OUT
    cout << "D = "; F.Print(); cout << endl;
    cout << "E = "; E.Print(); cout << endl;
    cout << "F = "; D.Print(); cout << endl;

    //PRINT THEM OUT
    cout << "G = "; G.Print(); cout << endl;
    cout << "H = "; H.Print(); cout << endl;
    cout << "I = "; I.Print(); cout << endl;

    //OPERATIONS ON SAME TYPE
    //PRINT THEM OUT
    cout << "A + B = "; (A+B).Print(); cout << endl;
    cout << "A - B = "; (A-B).Print(); cout << endl;
    cout << "A * B = "; (A*B).Print(); cout << endl;

    //PRINT THEM OUT
    cout << "D + F = "; (D+F).Print(); cout << endl;
    cout << "D - F = "; (D-F).Print(); cout << endl;
    cout << "D * F = "; (D*F).Print(); cout << endl;

    //PRINT THEM OUT
    cout << "G + H = "; (G+H).Print(); cout << endl;
    cout << "G - H = "; (G-H).Print(); cout << endl;
    cout << "G * H = "; (G*H).Print(); cout << endl;

    //OPERATIONS ON DIFFERENT TYPE
    //WILL NOT WORK: CAN YOU MAKE IT WORK

    //cout << "A + D = "; (A+D).Print(); cout << endl;
    //cout << "A - G = "; (A-G).Print(); cout << endl;
    //cout << "D * G = "; (D*G).Print(); cout << endl;

    return 0;
}