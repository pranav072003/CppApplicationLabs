#include <iostream>
#include <queue>
#include <unordered_map>

class HuffmanNode
{
public:
    char character;
    int frequency;
    HuffmanNode *left;
    HuffmanNode *right;

    HuffmanNode(char character, int frequency) : character(character), frequency(frequency), left(nullptr), right(nullptr) {}
};

struct CompareNodes
{
    bool operator()(HuffmanNode *node1, HuffmanNode *node2)
    {
        return node1->frequency > node2->frequency;
    }
};

class HuffmanTree
{
private:
    HuffmanNode *root;
    std::unordered_map<char, std::string> encodingMap;

public:
    HuffmanTree() : root(nullptr) {}

    void buildTree(std::unordered_map<char, int> &frequencyMap)
    {
        std::priority_queue<HuffmanNode *, std::vector<HuffmanNode *>, CompareNodes> minHeap;

        for (auto &pair : frequencyMap)
        {
            HuffmanNode *node = new HuffmanNode(pair.first, pair.second);
            minHeap.push(node);
        }

        while (minHeap.size() > 1)
        {
            HuffmanNode *leftNode = minHeap.top();
            minHeap.pop();
            HuffmanNode *rightNode = minHeap.top();
            minHeap.pop();

            HuffmanNode *parent = new HuffmanNode('$', leftNode->frequency + rightNode->frequency);
            parent->left = leftNode;
            parent->right = rightNode;

            minHeap.push(parent);
        }

        if (!minHeap.empty())
            root = minHeap.top();
    }

    void generateEncodingMap()
    {
        if (root == nullptr)
            return;

        generateEncodingMapHelper(root, "");
    }

    void generateEncodingMapHelper(HuffmanNode *node, std::string encoding)
    {
        if (node->left == nullptr && node->right == nullptr)
        {
            encodingMap[node->character] = encoding;
            return;
        }

        if (node->left != nullptr)
            generateEncodingMapHelper(node->left, encoding + "0");

        if (node->right != nullptr)
            generateEncodingMapHelper(node->right, encoding + "1");
    }

    std::string encode(const std::string &text)
    {
        std::string encodedText = "";
        for (char c : text)
        {
            encodedText += encodingMap[c];
        }
        return encodedText;
    }

    std::string decode(const std::string &encodedText)
    {
        std::string decodedText = "";
        HuffmanNode *current = root;

        for (char c : encodedText)
        {
            if (c == '0')
                current = current->left;
            else if (c == '1')
                current = current->right;

            if (current->left == nullptr && current->right == nullptr)
            {
                decodedText += current->character;
                current = root;
            }
        }

        return decodedText;
    }
};

int main()
{
    std::string text = "Huffman coding is a data compression algorithm.";
    std::unordered_map<char, int> frequencyMap;

    for (char c : text)
    {
        frequencyMap[c]++;
    }

    HuffmanTree huffmanTree;
    huffmanTree.buildTree(frequencyMap);
    huffmanTree.generateEncodingMap();

    std::string encodedText = huffmanTree.encode(text);
    std::cout << "Encoded text: " << encodedText << std::endl;

    std::string decodedText = huffmanTree.decode(encodedText);
    std::cout << "Decoded text: " << decodedText << std::endl;

    return 0;
}
