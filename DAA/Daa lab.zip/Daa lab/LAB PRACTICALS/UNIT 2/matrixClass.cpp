#include <iostream>
#include <vector>

class Matrix
{
private:
    std::vector<std::vector<int>> data;
    int rows;
    int columns;

public:
    Matrix(int rows, int columns) : rows(rows), columns(columns)
    {
        data.resize(rows, std::vector<int>(columns, 0));
    }

    int getRows() const
    {
        return rows;
    }

    int getColumns() const
    {
        return columns;
    }

    void setValue(int row, int column, int value)
    {
        if (row >= 0 && row < rows && column >= 0 && column < columns)
        {
            data[row][column] = value;
        }
    }

    int getValue(int row, int column) const
    {
        if (row >= 0 && row < rows && column >= 0 && column < columns)
        {
            return data[row][column];
        }
        else
        {
            return 0; // or throw an exception for out-of-bounds access
        }
    }

    void print() const
    {
        for (int i = 0; i < rows; ++i)
        {
            for (int j = 0; j < columns; ++j)
            {
                std::cout << data[i][j] << ' ';
            }
            std::cout << std::endl;
        }
    }
};

int main()
{
    
    Matrix matrix(3, 3);

    
    matrix.setValue(0, 0, 1);
    matrix.setValue(0, 1, 2);
    matrix.setValue(0, 2, 3);
    matrix.setValue(1, 0, 4);
    matrix.setValue(1, 1, 5);
    matrix.setValue(1, 2, 6);
    matrix.setValue(2, 0, 7);
    matrix.setValue(2, 1, 8);
    matrix.setValue(2, 2, 9);


    matrix.print();

    
    int value = matrix.getValue(1, 1);
    std::cout << "Value at (1, 1): " << value << std::endl;

    return 0;
}
