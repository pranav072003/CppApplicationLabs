#include <bits/stdc++.h>

std::pair<std::vector<std::vector<int>>, std::vector<std::vector<int>>> matrixChainOrder(const std::vector<int> &dimensions)
{
    int n = dimensions.size() - 1;
    std::vector<std::vector<int>> m(n, std::vector<int>(n, 0));
    std::vector<std::vector<int>> s(n, std::vector<int>(n, 0));

    for (int l = 2; l <= n; ++l)
    {
        for (int i = 0; i < n - l + 1; ++i)
        {
            int j = i + l - 1;
            m[i][j] = INT_MAX;
            for (int k = i; k < j; ++k)
            {
                int cost = m[i][k] + m[k + 1][j] + dimensions[i] * dimensions[k + 1] * dimensions[j + 1];
                if (cost < m[i][j])
                {
                    m[i][j] = cost;
                    s[i][j] = k;
                }
            }
        }
    }

    return std::make_pair(m, s);
}

void printOptimalParentheses(const std::vector<std::vector<int>> &s, int i, int j)
{
    if (i == j)
    {
        std::cout << "A" << i + 1;
    }
    else
    {
        std::cout << "(";
        printOptimalParentheses(s, i, s[i][j]);
        printOptimalParentheses(s, s[i][j] + 1, j);
        std::cout << ")";
    }
}

int main()
{
    std::vector<int> dimensions = {10, 30, 5, 60};
    int n = dimensions.size() - 1;

    std::pair<std::vector<std::vector<int>>, std::vector<std::vector<int>>> result = matrixChainOrder(dimensions);

    std::cout << "Minimum number of multiplications: " << result.first[0][n - 1] << std::endl;
    std::cout << "Optimal parenthesization: ";
    printOptimalParentheses(result.second, 0, n - 1);
    std::cout << std::endl;

    return 0;
}
