#include <iostream>
#include <vector>

class TreeNode
{
public:
    int key;
    double probability;
    TreeNode *left;
    TreeNode *right;

    TreeNode(int key, double probability) : key(key), probability(probability), left(nullptr), right(nullptr) {}
};

class BSTGenerator
{
public:
    std::vector<TreeNode *> generateAllBSTs(const std::vector<int> &keys, const std::vector<double> &probabilities)
    {
        return generateAllBSTsHelper(keys, probabilities, 0, keys.size() - 1);
    }

private:
    std::vector<TreeNode *> generateAllBSTsHelper(const std::vector<int> &keys, const std::vector<double> &probabilities, int start, int end)
    {
        std::vector<TreeNode *> result;

        if (start > end)
        {
            result.push_back(nullptr);
            return result;
        }

        for (int i = start; i <= end; ++i)
        {
            std::vector<TreeNode *> leftSubtrees = generateAllBSTsHelper(keys, probabilities, start, i - 1);
            std::vector<TreeNode *> rightSubtrees = generateAllBSTsHelper(keys, probabilities, i + 1, end);

            for (TreeNode *left : leftSubtrees)
            {
                for (TreeNode *right : rightSubtrees)
                {
                    TreeNode *node = new TreeNode(keys[i], probabilities[i]);
                    node->left = left;
                    node->right = right;
                    result.push_back(node);
                }
            }
        }

        return result;
    }
};

void printBST(TreeNode *root)
{
    if (root == nullptr)
        return;

    printBST(root->left);
    std::cout << "Key: " << root->key << ", Probability: " << root->probability << std::endl;
    printBST(root->right);
}

int main()
{
    std::vector<int> keys = {1, 2, 3};
    std::vector<double> probabilities = {0.2, 0.3, 0.5};

    BSTGenerator generator;
    std::vector<TreeNode *> bstList = generator.generateAllBSTs(keys, probabilities);

    for (int i = 0; i < bstList.size(); ++i)
    {
        std::cout << "BST " << i + 1 << ":" << std::endl;
        printBST(bstList[i]);
        std::cout << std::endl;
    }

    // Clean up dynamically allocated memory
    for (TreeNode *node : bstList)
    {
        delete node;
    }

    return 0;
}
