#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

void enqueue(int array[],int size,int vertexid,int *front,int *rear) //vertexid=id,rear=rear of queue,array=queue;
{
    if(*rear==-1 && *front==-1)
    {
        (*rear)++;
        (*front)++;
        array[*rear]=vertexid;
        return;
    }
    if((*rear+1)%size==*front)
    {
        return;
    }
    *rear=(*rear+1)%size;
    array[*rear]=vertexid;
    return;
}

void dequeue(int array[],int size,int *front,int *rear) //size=vertexno,rear=rear of queue,array=queue;
{
    if(*front==*rear)
    {
        *front=-1;
        *rear=-1;
        return;
    }
    *front=(*front+1)%size;
    return;
}

void traverse(int queue[],int front,int rear)
{
    if(front==-1 && rear==-1)
    {
        printf("Queue is empty\n");
        return;
    }
    if(front==rear)
    {
        printf("%d",queue[front]);
    }
    for(int i=front;i<rear;i++)
    {
        printf("%d\t",queue[i]);
    }
}

void BFS(int a,bool array[][a]) //array=adjacent;a=vertexno;
{
    int front_q=-1,rear_q=-1;
    int Q[a];
    //colour=1 for white;colour=2 for grey;colour=3 for black
    int colour[a];
    for(int i=0;i<a;i++)
    {
        colour[i]=1;
    }
    int i=0,u=1;
    printf("Starting from vertex %d\n",u);
    colour[0]++;
    printf("The BFS gives traversal as:-\n");
    // printf("n");
    enqueue(Q,a,u,&front_q,&rear_q);
    if(front_q!=-1 && rear_q!=-1)
    {
        Q[rear_q]=u;
    }
    while(front_q!=-1 && rear_q!=-1)
    {
        int p=Q[front_q];
        dequeue(Q,a,&front_q,&rear_q);
        for(int i=0;i<a;i++)
        {
            if(array[p-1][i]==true)
            {
                if(colour[i]==1)
                {
                    colour[i]++;
                    enqueue(Q,a,i+1,&front_q,&rear_q);
                    if(front_q!=-1 && rear_q!=-1)
                    {
                        Q[rear_q]=i+1;
                    }
                }
            }
        }
        colour[p-1]++;
        printf("%d\t",p);
    }
    printf("\n");
}

void DFS(int a,bool array[][a]) //array=adjacent;a=vertexno;
{
    int time=0;
    int colour[a];
    //1 for white;2 for grey;3 for black;
    for(int i=0;i<a;i++)
    {
        colour[i]=1;
    }
    int j=1;
    printf("Starting from vertex %d\n",j);
    printf("The DFS gives traversal as:-\n");
    printf("%d\t",j);
    for(int i=0;i<a;i++)
    {
        DFS_VISIT(i+1,colour,a,array);
    }
    printf("\n");
}

void DFS_VISIT(int u,int array[],int size,bool array1[][size]) //u=id;array=colour;size=a;
{
    // int timecount[size];
    array[u-1]++;
    for(int i=0;i<size;i++)
    {
        if(array1[u-1][i]==true)
        {
            if(array[i]==1)
            {
                printf("%d\t",i+1);
                DFS_VISIT(i+1,array,size,array1);
            }
        }
    }
    array[u-1]++;
}

int main() 
{
    while(1)
    {
        int key;
        printf("Want to initialise program(1 Y/0 N):-");
        scanf("%d",&key);
        if(key==0)
        {
            break;
        }
        else if(key!=1)
        {
            printf("Incorrect input. Try again\n");
            continue;
        }
        int vertexno;
        printf("Enter the number of vertices in the graph:-");
        scanf("%d",&vertexno);
        if(vertexno<=0)
        {
            printf("Incorrect input. Please try again\n");
            continue;
        }
        bool adjacent[vertexno][vertexno];
        int a,b;
        for(int i=0;i<vertexno;i++)
        {
            for(int j=0;j<vertexno;j++)
            {
                adjacent[i][j]=false;
            }
        }
        while(1)
        {
            if(vertexno<2)
            {
                break;
            }
            printf("Enter edge between vertices:-");
            scanf("%d %d",&a,&b);
            if(a==0 && b==0)
            {
                break;
            }
            if(a>vertexno || b>vertexno || a==0 || b==0)
            {
                printf("Incorrect input. Try again\n");
                continue;
            }
            if(adjacent[a-1][b-1]==true)
            {
                printf("Already done\n");
                continue;
            }
            adjacent[a-1][b-1]=true;
            adjacent[b-1][a-1]=true;
            int key;
            printf("Want to continue(1-Y/0-N):-");
            scanf("%d",&key);
            if(key==0)
            {
                break;
            }
            else if(key!=1)
            {
                printf("Incorrect input. Try again\n");
                continue;
            }
        }
        while(1)
        {
            int choice;
            printf("Want to implement DFS(1)/BFS(2)/Exit(3):-");
            scanf("%d",&choice);
            if(choice==1)
            {
                DFS(vertexno,adjacent);
            }
            else if(choice==2)
            {
                BFS(vertexno,adjacent);
            }
            else if(choice==3)
            {
                break;
            }
            else
            {
                printf("Incorrect input. Try again\n");
                continue;
            }
        }
    }
    printf("Program Terminated\n");

    return 0;
}
