#include <iostream>
#include <stdlib.h>
#include <stdbool.h>

using namespace std;

typedef struct node 
{
    int id;
    struct node* next;
}node;

typedef struct graph
{
    int vertex;
    struct graph* right;
    struct graph* up;
    struct graph* down;
}graph;

void add(graph* g,int id,int v)
{
    while(g!=NULL && g->vertex!=id)
    {
        g=g->down;
    }
    if(g->right==NULL)
    {
        g->right=(graph*)malloc(sizeof(graph));
        g->right->vertex=v;
        g->right->right=NULL;
        return;
    }
    while(g->right->right!=NULL)
    {
        g->right=g->right->right;
    }
    g->right->right=(graph*)malloc(sizeof(graph));
    g->right->right->vertex=v;
    g->right->right->right=NULL;
}

void del(graph *g,int id,int v)
{
    if(g==NULL) return;
    while(g!=NULL && g->vertex!=id)
    {
        g=g->down;
    }
    if(g->right==NULL)
    {
        return;
    }
    while(g->right->right->vertex!=v && g->right!=NULL && g->right->right!=NULL)
    {
        g->right=g->right->right;
    }
    if(g->right->right->vertex!=v) return;
    free(g->right->right);
    g->right->right=NULL;
    return;
}

bool search(graph *g,int id,int v)
{
    while(g!=NULL && g->vertex!=id)
    {
        g=g->down;
    }
    if(g->right==NULL)
    {
        return false;
    }
    while(g->right->right->vertex!=v && g->right!=NULL && g->right->right!=NULL)
    {
        g->right=g->right->right;
    }
    if(g->right->right->vertex!=v) return false;
    return true;
}

int main()
{
    int vertexno;
    cout<<"Enter number of vertices in the graph:-";
    cin>>vertexno;
    bool gph[vertexno][vertexno];
    graph* g=(graph*)malloc(sizeof(graph));
    g->up=NULL;
    g->up=NULL;
    for(int i=0;i<vertexno;i++)
    {
        g->vertex=i+1;
        g->right=NULL;
        if(i+1==vertexno) break;
        g->down=(graph*)malloc(sizeof(graph));
        g->down->up=g;
        g=g->down;
    }
    g->down=NULL;
    while(g->up!=NULL)
    {
        g=g->up;
    }
    while(1)
    {
        int a,b,op;
        cout<<"Enter edge between vertices:-\n";
        cin>>a>>b;
        if(a>vertexno || b>vertexno || a<=0 || b<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        gph[a-1][b-1]=true;
        add(g,a,b);
        cout<<"Want to Continue:-";
        cin>>op;
        if(op==0) break;
    }
    int graphop;
    cout<<"Want to implement (0: Undirected, 1: Directed):-\n";
    cin>>graphop;
    graph* ung=g;
    if(graphop==0)
    {
        for(int i=0;i<vertexno;i++)
        {
            for(int j=0;j<vertexno;j++)
            {
                if(gph[i][j]==true && gph[j][i]==false)
                {
                    add(ung,j+1,i+1);
                }
            }
        }
    }
    int gop;
    cout<<"Want to work on which graph (0: Undirected, 1: Directed):-\n";
    cin>>gop;
    if(gop==0)
    {
        int c,d;
        cout<<"Add an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        add(ung,c,d);
        add(ung,d,c);
        cout<<"Delete an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        del(ung,c,d);
        del(ung,d,c);
        cout<<"Search for an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        if(search(ung,c,d)==true && search(ung,d,c)==true)  cout<<"Search successfull\n";
        else cout<<"Search unsuccessfull\n";
        int edge=0;
        for(int i=0;i<vertexno;i++)
        {
            for(int j=0;j<vertexno;j++)
            {
                if(search(ung,i+1,j+1)==true && search(ung,j+1,i+1)==true)  edge++;    
            }
        }
        cout<<"Number of vertices and edges equal to "<<vertexno<<" and "<<edge<<" respectively"<<"\n";
        cout<<"Enter vertex for degree to be computed:-\n";
        cin>>c;
        if(c>vertexno || c<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        int degree=0;
        for(int i=0;i<vertexno;i++)
        {
            if(search(ung,c,i+1)==true && search(ung,i+1,c)==true) degree++;
        }
        cout<<"Degree of vertex "<<c<<" equal to "<<degree<<"\n";
    }
    else if(gop==1)
    {
        int c,d;
        cout<<"Add an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        add(g,c,d);
        cout<<"Delete an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        delete(g,c,d);
        cout<<"Search for an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        if(search(g,c,d)==true)  cout<<"Seach successfull\n";
        else cout<<"Search unsuccessfull\n";
        int edge=0;
        for(int i=0;i<vertexno;i++)
        {
            for(int j=0;j<vertexno;j++)
            {
                if(search(g,i+1,j+1)==true || search(g,j+1,i+1)==true)  edge++;    
            }
        }
        cout<<"Number of vertices and edges equal to "<<vertexno<<" and "<<edge<<" respectively"<<"\n";
        cout<<"Enter vertex for degree to be computed:-\n";
        cin>>c;
        if(c>vertexno || c<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        int indegree=0, outdegree=0;
        for(int i=0;i<vertexno;i++)
        {
            if(search(g,i+1,c)==true) indegree++;
            else if(search(g,c,i+1)==true) outdegree++;
        }
        cout<<"Indegree and outdegree of vertex "<<c<<" are equal to "<<indegree<<" and "<<outdegree<<" respectively"<<"\n";
    }
    
    return 0;
}
