#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int tim=0;

void swap(int *a, int *b) {
  int t = *a;
  *a = *b;
  *b = t;
}

// function to find the partition position
int partition(int array[], int low, int high) {
  
  // select the rightmost element as pivot
  int pivot = array[high];
  
  // pointer for greater element
  int i = (low - 1);

  // traverse each element of the array
  // compare them with the pivot
  for (int j = low; j < high; j++) {
    if (array[j] >= pivot) {
        
      // if element smaller than pivot is found
      // swap it with the greater element pointed by i
      i++;
      
      // swap element at i with element at j
      swap(&array[i], &array[j]);
    }
  }

  // swap the pivot element with the greater element at i
  swap(&array[i + 1], &array[high]);
  
  // return the partition point
  return (i + 1);
}

void quickSort(int array[], int low, int high) {
  if (low < high) {
    
    // find the pivot element such that
    // elements smaller than pivot are on left of pivot
    // elements greater than pivot are on right of pivot
    int pi = partition(array, low, high);
    
    // recursive call on the left of pivot
    quickSort(array, low, pi - 1);
    
    // recursive call on the right of pivot
    quickSort(array, pi + 1, high);
  }
}

void DFS(int a,bool array[][a]) //array=adjacent;a=vertexno;
{
    int time=0;
    int colour[a];
    int timecount[a];
    //1 for white;2 for grey;3 for black;
    printf("Topological sort of graph is given as:-\n");
    for(int i=0;i<a;i++)
    {
        colour[i]=1;
        timecount[i]=0;
    }
    for(int i=0;i<a;i++)
    {
        if(colour[i]==1) DFS_VISIT(i+1,colour,a,array,timecount);
    }
    int copy[a];
    for(int j=0;j<a;j++)
    {
        copy[j]=timecount[j];
    }
    quickSort(copy,0,a-1);
    int p=0;
    while(p<a)
    {
        for(int k=0;k<a;k++)
        {
            if(timecount[k]==copy[p])
            {
                printf("%d\t",k+1);
                break;
            }
        }    
        p++;
    }
    printf("\n");
}

void DFS_VISIT(int u,int array[],int size,bool array1[][size],int timecount[]) //u=id;array=colour;size=a;
{
    tim++;
    array[u-1]++;
    for(int i=0;i<size;i++)
    {
        if(array1[u-1][i]==true)
        {
            if(array[i]==1)
            {
                DFS_VISIT(i+1,array,size,array1,timecount);
            }
        }
    }
    array[u-1]++;
    tim++;
    timecount[u-1]=tim;
}

int main() 
{
    while(1)
    {
        int key;
        printf("Want to initialise program(1 Y/0 N):-");
        scanf("%d",&key);
        if(key==0)
        {
            break;
        }
        else if(key!=1)
        {
            printf("Incorrect input. Try again\n");
            continue;
        }
        int vertexno;
        printf("Enter the number of vertices in the graph:-");
        scanf("%d",&vertexno);
        if(vertexno<=0)
        {
            printf("Incorrect input. Please try again\n");
            continue;
        }
        bool adjacent[vertexno][vertexno];
        int a,b;
        for(int i=0;i<vertexno;i++)
        {
            for(int j=0;j<vertexno;j++)
            {
                adjacent[i][j]=false;
            }
        }
        while(1)
        {
            if(vertexno<2)
            {
                break;
            }
            printf("Enter edge between vertices:-");
            scanf("%d %d",&a,&b);
            if(a==0 && b==0)
            {
                break;
            }
            if(a>vertexno || b>vertexno || a==0 || b==0)
            {
                printf("Incorrect input. Try again\n");
                continue;
            }
            if(adjacent[a-1][b-1]==true)
            {
                printf("Already done\n");
                continue;
            }
            adjacent[a-1][b-1]=true;
            int key;
            printf("Want to continue(1-Y/0-N):-");
            scanf("%d",&key);
            if(key==0)
            {
                break;
            }
            else if(key!=1)
            {
                printf("Incorrect input. Try again\n");
                continue;
            }
        }
        DFS(vertexno,adjacent);
    }
    printf("Program Terminated\n");

    return 0;
}
