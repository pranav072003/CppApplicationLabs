#include <iostream>
#include <stdbool.h>

using namespace std;

int main()
{
    int vertexno;
    cout<<"Enter number of vertices in the graph:-";
    cin>>vertexno;
    bool graph[vertexno][vertexno];
    while(1)
    {
        int a,b,op;
        cout<<"Enter edge between vertices:-\n";
        cin>>a>>b;
        if(a>vertexno || b>vertexno || a<=0 || b<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        graph[a-1][b-1]=true;
        cout<<"Want to Continue:-";
        cin>>op;
        if(op==0) break;
    }
    int graphop;
    cout<<"Want to implement (0: Undirected, 1: Directed):-\n";
    cin>>graphop;
    bool directgraph[vertexno][vertexno];
    if(graphop==0)
    {
        for(int i=0;i<vertexno;i++)
        {
            for(int j=0;j<vertexno;j++)
            {
                directgraph[i][j]=graph[i][j];
            }
        }
        for(int i=0;i<vertexno;i++)
        {
            for(int j=0;j<vertexno;j++)
            {
                directgraph[i][j]=directgraph[j][i];
            }
        }
    }
    int gop;
    cout<<"Want to work on which graph (0: Undirected, 1: Directed):-\n";
    cin>>gop;
    if(gop==0)
    {
        int c,d;
        cout<<"Add an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        directgraph[c-1][d-1]=true;
        directgraph[d-1][c-1]=true;
        cout<<"Delete an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        directgraph[c-1][d-1]=false;
        directgraph[d-1][c-1]=false;
        cout<<"Search for an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        if(directgraph[c-1][d-1]==true && directgraph[d-1][c-1]==true)  cout<<"Seach successfull\n";
        else cout<<"Search unsuccessfull\n";
        int edge=0;
        for(int i=0;i<vertexno;i++)
        {
            for(int j=0;j<vertexno;j++)
            {
                if(directgraph[c-1][d-1]==true && directgraph[d-1][c-1]==true)  edge++;    
            }
        }
        cout<<"Number of vertices and edges equal to "<<vertexno<<" and "<<edge<<" respectively"<<"\n";
        cout<<"Enter vertex for degree to be computed:-\n";
        cin>>c;
        if(c>vertexno || c<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        int degree=0;
        for(int i=0;i<vertexno;i++)
        {
            if(directgraph[c-1][i]==true && directgraph[i][c-1]==true) degree++;
        }
        cout<<"Degree of vertex "<<c<<" equal to "<<degree<<"\n";
    }
    else if(gop==1)
    {
        int c,d;
        cout<<"Add an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        graph[c-1][d-1]=true;
        cout<<"Delete an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        graph[c-1][d-1]=false;
        cout<<"Search for an edge between vertices:-\n";
        cin>>c>>d;
        if(c>vertexno || d>vertexno || c<=0 || d<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        if(graph[c-1][d-1]==true)  cout<<"Search successfull\n";
        else cout<<"Search unsuccessfull\n";
        int edge=0;
        for(int i=0;i<vertexno;i++)
        {
            for(int j=0;j<vertexno;j++)
            {
                if(directgraph[c-1][d-1]==true && directgraph[d-1][c-1]==true)  edge++;    
            }
        }
        cout<<"Number of vertices and edges equal to "<<vertexno<<" and "<<edge<<" respectively"<<"\n";
        cout<<"Enter vertex for degree to be computed:-\n";
        cin>>c;
        if(c>vertexno || c<=0) 
        {
            cout<<"ERROR!\n";
            exit(1);
        }
        int indegree=0, outdegree=0;
        for(int i=0;i<vertexno;i++)
        {
            if(graph[i][c-1]==true) indegree++;
            else if(graph[c-1][i]==true) outdegree++;
        }
        cout<<"Indegree and outdegree of vertex "<<c<<" are equal to "<<indegree<<" and "<<outdegree<<" respectively"<<"\n";
    }
    
    return 0;
}
